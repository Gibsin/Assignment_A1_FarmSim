package students;


public class Field {
	
	public Field(int height, int width)
	{
	}
	
}
