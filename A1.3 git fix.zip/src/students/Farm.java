package students;

public class Farm {
	
	public Farm(int fieldWidth, int fieldHeight, int startingFunds)
	{
	}
	
	public void run()
	{
	}
	
}
